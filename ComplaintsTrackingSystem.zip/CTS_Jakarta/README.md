# Complaint Tracking System — Jakarta EE (Tomcat 11)

## What Was Changed (javax → jakarta migration)

| File | Change |
|------|--------|
| All `*.java` in `servlet/` | `javax.servlet.*` → `jakarta.servlet.*` |
| All `*.java` in `servlet/admin/` | `javax.servlet.*` → `jakarta.servlet.*` |
| All `*.java` in `servlet/user/` | `javax.servlet.*` → `jakarta.servlet.*` |
| `WebContent/WEB-INF/web.xml` | Updated namespace to `jakarta.ee` 6.0 (Servlet 6.0) |
| `pom.xml` | Added — uses `jakarta.servlet-api:6.0.0`, Java 17, Tomcat 11 |

---

## Prerequisites

- **Java 17+**
- **Apache Tomcat 11.x**
- **MySQL 8.x**
- **Maven 3.8+**

---

## Database Setup

1. Open MySQL and run:
```sql
SOURCE /path/to/database/complaint_db.sql;
```

2. Update `DBConnection.java` with your MySQL credentials:
```java
private static final String USER = "root";
private static final String PASS = "your_password_here";
```

---

## Build & Deploy

```bash
# 1. Build the WAR file
mvn clean package

# 2. Copy to Tomcat webapps
cp target/ComplaintTrackingSystem.war /path/to/tomcat11/webapps/

# 3. Start Tomcat
/path/to/tomcat11/bin/startup.sh

# 4. Access at:
http://localhost:8080/ComplaintTrackingSystem/
```

---

## Demo Credentials

| Role  | Email                  | Password  |
|-------|------------------------|-----------|
| Admin | admin@complaint.com    | admin123  |
| User  | rahul@email.com        | user123   |

---

## Project Structure

```
CTS_Jakarta/
├── pom.xml
├── database/
│   └── complaint_db.sql
├── src/com/complaint/
│   ├── db/DBConnection.java
│   ├── model/  (Complaint, User, ComplaintTimeline)
│   ├── dao/    (ComplaintDAO, UserDAO)
│   └── servlet/
│       ├── LoginServlet.java
│       ├── RegisterServlet.java
│       ├── LogoutServlet.java
│       ├── admin/  (AdminDashboardServlet, AdminViewServlet, AdminUpdateServlet)
│       └── user/   (MyComplaintsServlet, SubmitComplaintServlet, ViewComplaintServlet)
└── WebContent/
    ├── WEB-INF/web.xml   ← Jakarta EE 10 / Servlet 6.0
    ├── index.jsp
    ├── login.jsp
    ├── register.jsp
    ├── css/style.css
    ├── admin/ (dashboard.jsp, view_complaint.jsp)
    └── user/  (my_complaints.jsp, submit_complaint.jsp, view_complaint.jsp)
```
