package com.complaint.servlet.admin;

import com.complaint.dao.ComplaintDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet("/admin/update")
public class AdminUpdateServlet extends HttpServlet {
    private final ComplaintDAO dao = new ComplaintDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!"admin".equals(req.getSession().getAttribute("userRole"))) {
            res.sendRedirect(req.getContextPath() + "/login.jsp"); return;
        }
        int    id         = Integer.parseInt(req.getParameter("complaintId"));
        String status     = req.getParameter("status");
        String assignedTo = req.getParameter("assignedTo");
        String remarks    = req.getParameter("remarks");
        String updatedBy  = (String) req.getSession().getAttribute("userName");

        dao.updateComplaint(id, status, assignedTo, remarks, updatedBy);
        res.sendRedirect(req.getContextPath() + "/admin/view?id=" + id + "&updated=true");
    }
}
