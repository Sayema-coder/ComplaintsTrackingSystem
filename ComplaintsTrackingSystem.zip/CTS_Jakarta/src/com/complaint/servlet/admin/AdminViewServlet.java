package com.complaint.servlet.admin;

import com.complaint.dao.ComplaintDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet("/admin/view")
public class AdminViewServlet extends HttpServlet {
    private final ComplaintDAO dao = new ComplaintDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!"admin".equals(req.getSession().getAttribute("userRole"))) {
            res.sendRedirect(req.getContextPath() + "/login.jsp"); return;
        }
        int id = Integer.parseInt(req.getParameter("id"));
        req.setAttribute("complaint", dao.getComplaintById(id));
        req.setAttribute("timeline",  dao.getTimeline(id));
        req.getRequestDispatcher("/admin/view_complaint.jsp").forward(req, res);
    }
}
