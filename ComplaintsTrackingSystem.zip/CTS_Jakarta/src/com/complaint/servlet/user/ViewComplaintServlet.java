package com.complaint.servlet.user;

import com.complaint.dao.ComplaintDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet("/user/view")
public class ViewComplaintServlet extends HttpServlet {
    private final ComplaintDAO dao = new ComplaintDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (req.getSession().getAttribute("userId") == null) {
            res.sendRedirect(req.getContextPath() + "/login.jsp"); return;
        }
        int id = Integer.parseInt(req.getParameter("id"));
        req.setAttribute("complaint", dao.getComplaintById(id));
        req.setAttribute("timeline",  dao.getTimeline(id));
        req.getRequestDispatcher("/user/view_complaint.jsp").forward(req, res);
    }
}
