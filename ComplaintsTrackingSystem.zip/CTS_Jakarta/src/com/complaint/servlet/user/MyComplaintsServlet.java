package com.complaint.servlet.user;

import com.complaint.dao.ComplaintDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet("/user/mycomplaints")
public class MyComplaintsServlet extends HttpServlet {
    private final ComplaintDAO dao = new ComplaintDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        HttpSession session = req.getSession();
        if (session.getAttribute("userId") == null) {
            res.sendRedirect(req.getContextPath() + "/login.jsp"); return;
        }
        int userId = (int) session.getAttribute("userId");
        req.setAttribute("complaints", dao.getComplaintsByUser(userId));
        req.getRequestDispatcher("/user/my_complaints.jsp").forward(req, res);
    }
}
